#include "main.h"

void simulate(string filename)
{
	cout << "Good Luck";
	return;
}